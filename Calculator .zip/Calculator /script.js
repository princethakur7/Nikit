// Getting the display element
let display = document.getElementById('display');

// Function to append value to the display
function appendValue(value) {
    display.value += value;
}

// Function to clear the display
function clearDisplay() {
    display.value = '';
}

// function to clear display
function clearDisplay() {
    display.value = '';
}

// Function to delete the last character from the display
function deleteLast() {
    let display = document.getElementById("display");
    display.value = display.value.slice(0, -1);
}

// Function to clacualte answer 
function calculate(){
    display.value = eval(display.value);
}